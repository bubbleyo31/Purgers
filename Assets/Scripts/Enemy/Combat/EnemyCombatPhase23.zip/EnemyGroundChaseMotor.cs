using Fusion;
using UnityEngine;
using UnityEngine.AI;


/// <summary>
/// 追逐 A：地面 NavMesh 最短完整路徑，加上每隻敵人的環形接近偏移。
///
/// 偏移只避免所有近戰敵人瞄準完全相同的玩家 Root；
/// 本階段尚未實作動態群體避讓與正式位置預約。
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(EnemyMovementOwnership))]
public sealed class EnemyGroundChaseMotor :
    EnemyChaseMotor
{
    [Header("Chase A：NavMesh")]

    [SerializeField]
    [Tooltip("NavMesh Agent Type ID。必須與地面巡邏使用的烘焙類型一致；預設 Humanoid 通常為 0。")]
    private int agentTypeId;

    [SerializeField]
    [Min(0.01f)]
    [Tooltip("將玩家周圍接近點投影到最近 NavMesh 的最大距離，公尺。過大可能投影到另一層樓。")]
    private float navMeshSnapDistance =
        1f;

    [SerializeField]
    [Range(0f, 1f)]
    [Tooltip(
        "近戰接近位置使用最大攻擊距離的比例。\n" +
        "0.7 代表移動到最大攻擊距離內約 70% 的位置，留出網路與移動緩衝。")]
    private float attackRangeApproachRatio =
        0.7f;

    [SerializeField]
    [Range(0f, 1f)]
    [Tooltip(
        "玩家周圍環形位置的側向擾動比例。\n" +
        "數值越大，不同敵人越會從不同角度接近；0 代表沿當前最短方向。")]
    private float surroundVariation =
        0.35f;

    private NavMeshPath path;
    private Vector3[] corners;
    private int cornerIndex;
    private float personalAngleOffset;

    public override EnemyChaseKind SupportedChaseKind =>
        EnemyChaseKind.ChaseA;

    protected override void Awake()
    {
        base.Awake();
        path = new NavMeshPath();

        // 只有 State Authority 使用規劃結果；角度不需要額外同步。
        personalAngleOffset =
            Random.Range(-90f, 90f);
    }

    public override bool TryPlanDestination(
        NetworkObject target,
        Vector3 targetPosition,
        bool hasDirectSight,
        float minimumAttackDistance,
        float maximumAttackDistance,
        out Vector3 destination
    )
    {
        destination = targetPosition;

        if (CanMove == false ||
            path == null)
        {
            return false;
        }

        Vector3 playerRootPosition =
            target != null && target.IsValid
                ? target.transform.position
                : targetPosition;

        Vector3 awayFromPlayer =
            Vector3.ProjectOnPlane(
                transform.position - playerRootPosition,
                Vector3.up
            );

        if (awayFromPlayer.sqrMagnitude <= 0.0001f)
        {
            awayFromPlayer = -transform.forward;
        }

        float approachDistance =
            Mathf.Max(
                0.15f,
                Mathf.Lerp(
                    minimumAttackDistance,
                    maximumAttackDistance,
                    attackRangeApproachRatio
                )
            );

        float appliedAngle =
            personalAngleOffset *
            surroundVariation;

        Vector3 ringDirection =
            Quaternion.AngleAxis(
                appliedAngle,
                Vector3.up
            ) * awayFromPlayer.normalized;

        Vector3 desired =
            playerRootPosition +
            ringDirection * approachDistance;

        NavMeshQueryFilter filter =
            new NavMeshQueryFilter
            {
                agentTypeID = agentTypeId,
                areaMask = NavMesh.AllAreas
            };

        if (NavMesh.SamplePosition(
                transform.position,
                out NavMeshHit start,
                navMeshSnapDistance,
                filter
            ) == false ||
            NavMesh.SamplePosition(
                desired,
                out NavMeshHit end,
                navMeshSnapDistance,
                filter
            ) == false ||
            NavMesh.CalculatePath(
                start.position,
                end.position,
                filter,
                path
            ) == false ||
            path.status != NavMeshPathStatus.PathComplete)
        {
            corners = null;
            return false;
        }

        corners = path.corners;
        cornerIndex =
            corners.Length > 1
                ? 1
                : 0;

        destination = end.position;
        return corners.Length > 0;
    }

    public override bool TickMove(
        Vector3 destination,
        float deltaTime,
        float stoppingDistance,
        out float actualSpeed
    )
    {
        actualSpeed = 0f;

        if (CanMove == false ||
            corners == null ||
            corners.Length == 0)
        {
            return false;
        }

        if (Vector3.Distance(
                transform.position,
                destination
            ) <= stoppingDistance)
        {
            return true;
        }

        while (cornerIndex < corners.Length - 1 &&
               Vector3.Distance(
                   transform.position,
                   corners[cornerIndex]
               ) <= 0.08f)
        {
            cornerIndex++;
        }

        Vector3 before = transform.position;
        Vector3 next =
            Vector3.MoveTowards(
                before,
                corners[cornerIndex],
                chaseSpeed * deltaTime
            );

        if (TryMoveRoot(next, deltaTime) == false)
        {
            return false;
        }

        actualSpeed =
            Vector3.Distance(before, transform.position) /
            Mathf.Max(0.0001f, deltaTime);

        return true;
    }

    public override void Stop()
    {
        corners = null;
        cornerIndex = 0;
    }
}
