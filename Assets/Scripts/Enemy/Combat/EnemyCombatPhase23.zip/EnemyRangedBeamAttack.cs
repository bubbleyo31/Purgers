using Fusion;
using UnityEngine;


/// <summary>
/// 遠程攻擊 B：追蹤瞄準 → 鎖定世界點 → 延遲 → 瞬間 Beam／Hitscan。
///
/// Tracking 期間失去直接視線就取消並進入短冷卻；
/// LockedDelay 後不再跟隨玩家，玩家可以離開固定射線位置來閃避。
/// </summary>
[DisallowMultipleComponent]
public sealed class EnemyRangedBeamAttack :
    EnemyCombatOption
{
    [Header("遠程 B 引用")]

    [SerializeField]
    [Tooltip("Beam 起點。通常是穩定的槍口 Transform；若留空使用 Enemy Root。")]
    private Transform muzzle;

    [SerializeField]
    [Tooltip("Hitscan 會命中的 Layer。必須包含 Player 與場景實體，不可包含 Enemy Layer。")]
    private LayerMask beamHitMask;

    [Header("遠程 B 時間")]

    [SerializeField]
    [Min(0.02f)]
    [Tooltip("Line 持續跟隨玩家胸口的瞄準秒數。設計確認值為 1 秒。")]
    private float trackingSeconds =
        1f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("停止跟隨並鎖定世界點後，到正式發射 Hitscan 的等待秒數。設計確認值為 0.5 秒。")]
    private float lockedDelaySeconds =
        0.5f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("Hitscan 發射後的收招秒數。")]
    private float recoverySeconds =
        0.5f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("完整攻擊結束後的普通冷卻秒數。")]
    private float cooldownSeconds =
        4f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("Tracking 期間因視線被牆擋住而取消時使用的短冷卻秒數。")]
    private float cancelledCooldownSeconds =
        0.8f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("發射瞬間的 Beam 線保留顯示幾秒。只影響呈現，不影響傷害。")]
    private float shotBeamVisibleSeconds =
        0.08f;

    [SerializeField]
    [Min(1f)]
    [Tooltip("Tracking 期間水平朝向玩家的最大角速度，度／秒。")]
    private float trackingTurnSpeed =
        180f;

    [Header("遠程 B 傷害")]

    [SerializeField]
    [Min(0f)]
    [Tooltip("瞬間 Beam 命中玩家時造成的基礎 Bullet 傷害。")]
    private float damage =
        35f;

    [SerializeField]
    [Min(0f)]
    [Tooltip(
        "鎖定點後方額外延伸多少公尺做 Hitscan。\n" +
        "0 代表只射到原鎖定距離；小幅延伸可避免玩家當時位於胸口點邊緣而漏判。")]
    private float rayExtensionDistance =
        1f;

    [Header("除錯")]

    [SerializeField]
    [Tooltip("開啟後輸出視線取消與 Hitscan 命中結果。")]
    private bool debugBeamAttack;

    [Networked]
    public TickTimer PhaseTimer
    {
        get;
        private set;
    }

    [Networked]
    public TickTimer CooldownTimer
    {
        get;
        private set;
    }

    [Networked]
    public TickTimer ShotVisualTimer
    {
        get;
        private set;
    }

    [Networked]
    public Vector3 BeamStartPoint
    {
        get;
        private set;
    }

    [Networked]
    public Vector3 BeamEndPoint
    {
        get;
        private set;
    }

    [Networked]
    public int BeamShotSequence
    {
        get;
        private set;
    }

    [Networked]
    public bool LastShotHitPlayer
    {
        get;
        private set;
    }

    public bool IsShotVisualActive =>
        Object != null &&
        Object.IsValid &&
        ShotVisualTimer.ExpiredOrNotRunning(Runner) == false;

    public override EnemyActionState ActionState =>
        EnemyActionState.Attack;

    public override EnemyActionLockFlags LocksWhileActive =>
        EnemyActionLockFlags.Movement |
        EnemyActionLockFlags.Rotation |
        EnemyActionLockFlags.Navigation |
        EnemyActionLockFlags.Attack |
        EnemyActionLockFlags.Defense;

    public override void Spawned()
    {
        if (Object.HasStateAuthority)
        {
            PhaseTimer = TickTimer.None;
            CooldownTimer = TickTimer.None;
            ShotVisualTimer = TickTimer.None;
            BeamStartPoint = GetMuzzlePosition();
            BeamEndPoint = BeamStartPoint;
            BeamShotSequence = 0;
            LastShotHitPlayer = false;
        }
    }

    public override bool IsCooldownReady(
        NetworkRunner runner
    )
    {
        return CooldownTimer.ExpiredOrNotRunning(runner);
    }

    public override bool CanStartOption(
        in EnemyCombatContext context
    )
    {
        return beamHitMask.value != 0;
    }

    public override void BeginOption(
        in EnemyCombatContext context
    )
    {
        UpdateTrackingPoints(context);
        PhaseTimer = TickTimer.CreateFromSeconds(
            Runner,
            trackingSeconds
        );

        context.Controller.TrySetActionPhase(
            this,
            EnemyCombatActionPhase.Tracking
        );
    }

    public override EnemyCombatOptionTickResult TickOption(
        in EnemyCombatContext context
    )
    {
        switch (context.Controller.CurrentActionPhase)
        {
            case EnemyCombatActionPhase.Tracking:
                if (context.Perception.HasDirectSight == false)
                {
                    StartCooldown(cancelledCooldownSeconds);

                    if (debugBeamAttack)
                    {
                        Debug.Log(
                            "[Enemy Beam] Tracking 期間失去視線，取消並進短冷卻。",
                            this
                        );
                    }

                    return EnemyCombatOptionTickResult.Cancelled;
                }

                UpdateTrackingPoints(context);

                if (PhaseTimer.ExpiredOrNotRunning(Runner))
                {
                    PhaseTimer =
                        lockedDelaySeconds > 0f
                            ? TickTimer.CreateFromSeconds(
                                Runner,
                                lockedDelaySeconds
                            )
                            : TickTimer.None;

                    context.Controller.TrySetActionPhase(
                        this,
                        EnemyCombatActionPhase.LockedDelay
                    );
                }

                return EnemyCombatOptionTickResult.Running;

            case EnemyCombatActionPhase.LockedDelay:
                // 槍口可能隨動畫移動；終點保持上一階段鎖定的世界座標。
                BeamStartPoint = GetMuzzlePosition();

                if (PhaseTimer.ExpiredOrNotRunning(Runner))
                {
                    FireHitscan(context);
                    PhaseTimer =
                        recoverySeconds > 0f
                            ? TickTimer.CreateFromSeconds(
                                Runner,
                                recoverySeconds
                            )
                            : TickTimer.None;

                    context.Controller.TrySetActionPhase(
                        this,
                        EnemyCombatActionPhase.Recovery
                    );
                }

                return EnemyCombatOptionTickResult.Running;

            case EnemyCombatActionPhase.Recovery:
                if (PhaseTimer.ExpiredOrNotRunning(Runner))
                {
                    StartCooldown(cooldownSeconds);
                    return EnemyCombatOptionTickResult.Completed;
                }

                return EnemyCombatOptionTickResult.Running;

            default:
                StartCooldown(cancelledCooldownSeconds);
                return EnemyCombatOptionTickResult.Cancelled;
        }
    }

    public override void CancelOption(
        in EnemyCombatContext context
    )
    {
        PhaseTimer = TickTimer.None;
        StartCooldown(cancelledCooldownSeconds);
    }

    private void UpdateTrackingPoints(
        in EnemyCombatContext context
    )
    {
        BeamStartPoint = GetMuzzlePosition();
        BeamEndPoint = context.TargetPosition;

        Vector3 horizontal =
            Vector3.ProjectOnPlane(
                BeamEndPoint - transform.position,
                Vector3.up
            );

        if (horizontal.sqrMagnitude > 0.0001f)
        {
            transform.rotation =
                Quaternion.RotateTowards(
                    transform.rotation,
                    Quaternion.LookRotation(horizontal),
                    trackingTurnSpeed * context.DeltaTime
                );
        }
    }

    private void FireHitscan(
        in EnemyCombatContext context
    )
    {
        Vector3 direction =
            BeamEndPoint - BeamStartPoint;

        float lockedDistance =
            direction.magnitude;

        if (lockedDistance <= 0.001f)
        {
            direction = transform.forward;
            lockedDistance = 0.001f;
        }
        else
        {
            direction /= lockedDistance;
        }

        float castDistance =
            lockedDistance + rayExtensionDistance;

        BeamShotSequence++;
        LastShotHitPlayer = false;

        if (Runner.GetPhysicsScene().Raycast(
                BeamStartPoint,
                direction,
                out RaycastHit hit,
                castDistance,
                beamHitMask,
                QueryTriggerInteraction.Ignore
            ))
        {
            BeamEndPoint = hit.point;

            PlayerHealth health =
                hit.collider != null
                    ? hit.collider.GetComponentInParent<PlayerHealth>()
                    : null;

            if (health != null &&
                health.Object != null &&
                health.IsAlive)
            {
                LastShotHitPlayer =
                    EnemyDamageUtility.TryDamagePlayer(
                        context.Actor,
                        health.Object,
                        hit.collider.gameObject,
                        hit.point,
                        hit.normal,
                        direction,
                        damage,
                        DamageType.Bullet,
                        BeamShotSequence,
                        out DamageResult result
                    ) && result.HasEffectiveDamage;
            }
        }
        else
        {
            BeamEndPoint =
                BeamStartPoint +
                direction * castDistance;
        }

        ShotVisualTimer =
            TickTimer.CreateFromSeconds(
                Runner,
                Mathf.Max(
                    Runner.DeltaTime,
                    shotBeamVisibleSeconds
                )
            );

        if (debugBeamAttack)
        {
            Debug.Log(
                $"[Enemy Beam] Hitscan 發射。" +
                $"\nHit Player：{LastShotHitPlayer}" +
                $"\nSequence：{BeamShotSequence}",
                this
            );
        }
    }

    private Vector3 GetMuzzlePosition()
    {
        return muzzle != null
            ? muzzle.position
            : transform.position;
    }

    private void StartCooldown(
        float duration
    )
    {
        CooldownTimer =
            duration > 0f
                ? TickTimer.CreateFromSeconds(
                    Runner,
                    duration
                )
                : TickTimer.None;
    }

    protected override void OnValidate()
    {
        base.OnValidate();
        trackingSeconds = Mathf.Max(0.02f, trackingSeconds);
        lockedDelaySeconds = Mathf.Max(0f, lockedDelaySeconds);
        recoverySeconds = Mathf.Max(0f, recoverySeconds);
        cooldownSeconds = Mathf.Max(0f, cooldownSeconds);
        cancelledCooldownSeconds = Mathf.Max(0f, cancelledCooldownSeconds);
        shotBeamVisibleSeconds = Mathf.Max(0f, shotBeamVisibleSeconds);
        trackingTurnSpeed = Mathf.Max(1f, trackingTurnSpeed);
        damage = Mathf.Max(0f, damage);
        rayExtensionDistance = Mathf.Max(0f, rayExtensionDistance);
    }
}
