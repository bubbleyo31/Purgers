using Fusion;
using UnityEngine;


/// <summary>
/// 近戰 A／B 共用的直線衝擊攻擊。
///
/// A 可設定成短距離快速突進；B 設成較長、前搖明顯的直線衝刺。
/// Startup 期間朝向目標，進入 Active 的瞬間鎖定方向，之後不可轉向。
/// Active 結束後先減速 Braking，再進 Recovery，不瞬間把速度清零。
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(EnemyMovementOwnership))]
public sealed class EnemyMeleeDashAttack :
    EnemyCombatOption
{
    [Header("近戰衝擊時間")]

    [SerializeField]
    [Min(0f)]
    [Tooltip(
        "正式開始衝刺前的前搖秒數。\n" +
        "傷害與衝刺由 TickTimer 觸發，不使用 Animation Event。")]
    private float startupSeconds =
        0.45f;

    [SerializeField]
    [Min(0.02f)]
    [Tooltip("直線衝刺最多維持幾秒。即使沒有碰撞也會在此時間後開始減速。")]
    private float maximumActiveSeconds =
        0.8f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("減速階段最多維持幾秒。速度會依 Braking Deceleration 降到 0。")]
    private float maximumBrakingSeconds =
        0.25f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("減速完成後的收招秒數。期間仍不能再次攻擊或防禦。")]
    private float recoverySeconds =
        0.45f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("整個攻擊完成或取消後的冷卻秒數。冷卻從能力結束後開始。")]
    private float cooldownSeconds =
        2f;

    [Header("衝刺移動")]

    [SerializeField]
    [Min(0.01f)]
    [Tooltip("Active 直線衝刺速度，公尺／秒。")]
    private float dashSpeed =
        10f;

    [SerializeField]
    [Min(0.01f)]
    [Tooltip("一次攻擊允許移動的最大累積距離，公尺。")]
    private float maximumDashDistance =
        7f;

    [SerializeField]
    [Min(0.01f)]
    [Tooltip("Braking 每秒減少多少速度。數值越高越快停下，但仍不是瞬間歸零。")]
    private float brakingDeceleration =
        40f;

    [SerializeField]
    [Min(1f)]
    [Tooltip("Startup 期間朝向目前玩家的旋轉速度，度／秒。Active 後完全不再轉向。")]
    private float startupTurnSpeed =
        360f;

    [SerializeField]
    [Range(1f, 180f)]
    [Tooltip("允許開始攻擊時，玩家與敵人正前方的最大水平夾角。90 代表前方 180 度。")]
    private float startFacingHalfAngle =
        70f;

    [Header("碰撞與傷害")]

    [SerializeField]
    [Tooltip(
        "衝刺會碰撞的 Layer。必須包含 Player 與場景實體，不可包含 Enemy 自身 Layer。\n" +
        "最先撞到牆或玩家就停止造成後續衝刺傷害。")]
    private LayerMask dashHitMask;

    [SerializeField]
    [Min(0.01f)]
    [Tooltip("衝撞傷害球半徑，公尺。")]
    private float hitRadius =
        0.55f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("傷害球中心相對 Enemy Root 的向上高度，公尺。")]
    private float hitCenterHeight =
        0.9f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("撞到玩家時造成的基礎近戰傷害。只會命中一次。")]
    private float damage =
        25f;

    [Header("近戰 B 轉身閃避規則")]

    [SerializeField]
    [Min(0f)]
    [Tooltip(
        "Active 期間，鎖定玩家連續位於固定衝刺方向後方多久就取消衝刺。\n\n" +
        "近戰 B 設 1.5。近戰 A 若不需要此規則可設 0。\n" +
        "玩家回到前方時會重置連續計時。")]
    private float cancelWhenTargetBehindSeconds =
        1.5f;

    [Header("除錯")]

    [SerializeField]
    [Tooltip("開啟後輸出衝刺命中、碰牆、距離結束與玩家離開後方視野等原因。")]
    private bool debugMeleeDash;

    [Networked]
    public TickTimer PhaseTimer
    {
        get;
        private set;
    }

    [Networked]
    public TickTimer CooldownTimer
    {
        get;
        private set;
    }

    [Networked]
    private TickTimer BehindTimer
    {
        get;
        set;
    }

    [Networked]
    public Vector3 LockedDashDirection
    {
        get;
        private set;
    }

    [Networked]
    public float CurrentDashSpeed
    {
        get;
        private set;
    }

    [Networked]
    public float TravelledDistance
    {
        get;
        private set;
    }

    [Networked]
    public int DamageSequence
    {
        get;
        private set;
    }

    private EnemyMovementOwnership movementOwnership;

    public override EnemyActionState ActionState =>
        EnemyActionState.Attack;

    public override EnemyActionLockFlags LocksWhileActive =>
        EnemyActionLockFlags.Movement |
        EnemyActionLockFlags.Rotation |
        EnemyActionLockFlags.Navigation |
        EnemyActionLockFlags.Attack |
        EnemyActionLockFlags.Defense;

    private void Awake()
    {
        movementOwnership =
            GetComponent<EnemyMovementOwnership>();
    }

    public override void Spawned()
    {
        if (Object.HasStateAuthority == false)
        {
            return;
        }

        PhaseTimer = TickTimer.None;
        CooldownTimer = TickTimer.None;
        BehindTimer = TickTimer.None;
        LockedDashDirection = transform.forward;
        CurrentDashSpeed = 0f;
        TravelledDistance = 0f;
        DamageSequence = 0;
    }

    public override bool IsCooldownReady(
        NetworkRunner runner
    )
    {
        return CooldownTimer.ExpiredOrNotRunning(runner);
    }

    public override bool CanStartOption(
        in EnemyCombatContext context
    )
    {
        Vector3 toTarget =
            Vector3.ProjectOnPlane(
                context.TargetPosition - transform.position,
                Vector3.up
            );

        if (toTarget.sqrMagnitude <= 0.0001f)
        {
            return false;
        }

        return Vector3.Angle(
                   transform.forward,
                   toTarget
               ) <= startFacingHalfAngle &&
               movementOwnership != null &&
               movementOwnership.IsExternallyMoved == false &&
               dashHitMask.value != 0;
    }

    public override void BeginOption(
        in EnemyCombatContext context
    )
    {
        TravelledDistance = 0f;
        CurrentDashSpeed = 0f;
        BehindTimer = TickTimer.None;
        UpdateStartupFacing(context);

        PhaseTimer =
            startupSeconds > 0f
                ? TickTimer.CreateFromSeconds(
                    Runner,
                    startupSeconds
                )
                : TickTimer.None;
    }

    public override EnemyCombatOptionTickResult TickOption(
        in EnemyCombatContext context
    )
    {
        if (movementOwnership == null ||
            movementOwnership.IsExternallyMoved)
        {
            StartCooldown();
            return EnemyCombatOptionTickResult.Cancelled;
        }

        switch (context.Controller.CurrentActionPhase)
        {
            case EnemyCombatActionPhase.Startup:
                return TickStartup(context);

            case EnemyCombatActionPhase.Active:
                return TickActive(context);

            case EnemyCombatActionPhase.Braking:
                return TickBraking(context);

            case EnemyCombatActionPhase.Recovery:
                if (PhaseTimer.ExpiredOrNotRunning(Runner))
                {
                    StartCooldown();
                    return EnemyCombatOptionTickResult.Completed;
                }

                return EnemyCombatOptionTickResult.Running;

            default:
                StartCooldown();
                return EnemyCombatOptionTickResult.Cancelled;
        }
    }

    public override void CancelOption(
        in EnemyCombatContext context
    )
    {
        CurrentDashSpeed = 0f;
        BehindTimer = TickTimer.None;
        PhaseTimer = TickTimer.None;
        StartCooldown();
    }

    private EnemyCombatOptionTickResult TickStartup(
        in EnemyCombatContext context
    )
    {
        UpdateStartupFacing(context);

        if (PhaseTimer.ExpiredOrNotRunning(Runner) == false)
        {
            return EnemyCombatOptionTickResult.Running;
        }

        Vector3 horizontal =
            Vector3.ProjectOnPlane(
                context.TargetPosition - transform.position,
                Vector3.up
            );

        if (horizontal.sqrMagnitude <= 0.0001f)
        {
            StartCooldown();
            return EnemyCombatOptionTickResult.Cancelled;
        }

        LockedDashDirection =
            horizontal.normalized;

        transform.rotation =
            Quaternion.LookRotation(LockedDashDirection);

        CurrentDashSpeed = dashSpeed;
        PhaseTimer = TickTimer.CreateFromSeconds(
            Runner,
            maximumActiveSeconds
        );

        context.Controller.TrySetActionPhase(
            this,
            EnemyCombatActionPhase.Active
        );

        return EnemyCombatOptionTickResult.Running;
    }

    private EnemyCombatOptionTickResult TickActive(
        in EnemyCombatContext context
    )
    {
        if (ShouldCancelForTargetBehind(context))
        {
            BeginBraking("玩家連續位於固定衝刺方向後方");
            return EnemyCombatOptionTickResult.Running;
        }

        if (PhaseTimer.ExpiredOrNotRunning(Runner) ||
            TravelledDistance >= maximumDashDistance)
        {
            BeginBraking("達到最大時間或距離");
            return EnemyCombatOptionTickResult.Running;
        }

        float step =
            Mathf.Min(
                CurrentDashSpeed * context.DeltaTime,
                maximumDashDistance - TravelledDistance
            );

        if (step <= 0f)
        {
            BeginBraking("移動距離為零");
            return EnemyCombatOptionTickResult.Running;
        }

        Vector3 origin =
            transform.position +
            Vector3.up * hitCenterHeight;

        if (Runner.GetPhysicsScene().SphereCast(
                origin,
                hitRadius,
                LockedDashDirection,
                out RaycastHit hit,
                step,
                dashHitMask,
                QueryTriggerInteraction.Ignore
            ))
        {
            Vector3 allowedMove =
                LockedDashDirection *
                Mathf.Max(0f, hit.distance - 0.02f);

            transform.position += allowedMove;
            TravelledDistance += allowedMove.magnitude;

            PlayerHealth playerHealth =
                hit.collider != null
                    ? hit.collider.GetComponentInParent<PlayerHealth>()
                    : null;

            if (playerHealth != null &&
                playerHealth.Object != null &&
                playerHealth.IsAlive)
            {
                DamageSequence++;

                EnemyDamageUtility.TryDamagePlayer(
                    context.Actor,
                    playerHealth.Object,
                    hit.collider.gameObject,
                    hit.point,
                    hit.normal,
                    LockedDashDirection,
                    damage,
                    DamageType.Melee,
                    DamageSequence,
                    out _
                );

                BeginBraking("命中玩家");
            }
            else
            {
                BeginBraking("撞到場景障礙");
            }

            return EnemyCombatOptionTickResult.Running;
        }

        transform.position +=
            LockedDashDirection * step;

        TravelledDistance += step;
        return EnemyCombatOptionTickResult.Running;
    }

    private EnemyCombatOptionTickResult TickBraking(
        in EnemyCombatContext context
    )
    {
        CurrentDashSpeed =
            Mathf.MoveTowards(
                CurrentDashSpeed,
                0f,
                brakingDeceleration * context.DeltaTime
            );

        float step =
            CurrentDashSpeed * context.DeltaTime;

        if (step > 0f &&
            Runner.GetPhysicsScene().SphereCast(
                transform.position +
                Vector3.up * hitCenterHeight,
                hitRadius,
                LockedDashDirection,
                out RaycastHit hit,
                step,
                dashHitMask,
                QueryTriggerInteraction.Ignore
            ) == false)
        {
            transform.position +=
                LockedDashDirection * step;
        }
        else if (step > 0f)
        {
            CurrentDashSpeed = 0f;
        }

        if (CurrentDashSpeed <= 0.001f ||
            PhaseTimer.ExpiredOrNotRunning(Runner))
        {
            CurrentDashSpeed = 0f;
            BeginRecovery(context);
        }

        return EnemyCombatOptionTickResult.Running;
    }

    private void UpdateStartupFacing(
        in EnemyCombatContext context
    )
    {
        Vector3 horizontal =
            Vector3.ProjectOnPlane(
                context.TargetPosition - transform.position,
                Vector3.up
            );

        if (horizontal.sqrMagnitude <= 0.0001f)
        {
            return;
        }

        transform.rotation =
            Quaternion.RotateTowards(
                transform.rotation,
                Quaternion.LookRotation(horizontal),
                startupTurnSpeed * context.DeltaTime
            );
    }

    private bool ShouldCancelForTargetBehind(
        in EnemyCombatContext context
    )
    {
        if (cancelWhenTargetBehindSeconds <= 0f)
        {
            return false;
        }

        Vector3 toTarget =
            Vector3.ProjectOnPlane(
                context.TargetPosition - transform.position,
                Vector3.up
            );

        bool isBehind =
            toTarget.sqrMagnitude > 0.0001f &&
            Vector3.Dot(
                LockedDashDirection,
                toTarget.normalized
            ) < 0f;

        if (isBehind == false)
        {
            BehindTimer = TickTimer.None;
            return false;
        }

        if (BehindTimer.IsRunning == false)
        {
            BehindTimer = TickTimer.CreateFromSeconds(
                Runner,
                cancelWhenTargetBehindSeconds
            );
        }

        return BehindTimer.Expired(Runner);
    }

    private void BeginBraking(
        string reason
    )
    {
        BehindTimer = TickTimer.None;
        PhaseTimer =
            maximumBrakingSeconds > 0f
                ? TickTimer.CreateFromSeconds(
                    Runner,
                    maximumBrakingSeconds
                )
                : TickTimer.None;

        GetComponent<EnemyCombatDecisionController>()
            .TrySetActionPhase(
                this,
                EnemyCombatActionPhase.Braking
            );

        if (debugMeleeDash)
        {
            Debug.Log(
                $"[{nameof(EnemyMeleeDashAttack)}] 開始減速：{reason}",
                this
            );
        }
    }

    private void BeginRecovery(
        in EnemyCombatContext context
    )
    {
        PhaseTimer =
            recoverySeconds > 0f
                ? TickTimer.CreateFromSeconds(
                    Runner,
                    recoverySeconds
                )
                : TickTimer.None;

        context.Controller.TrySetActionPhase(
            this,
            EnemyCombatActionPhase.Recovery
        );
    }

    private void StartCooldown()
    {
        CooldownTimer =
            cooldownSeconds > 0f
                ? TickTimer.CreateFromSeconds(
                    Runner,
                    cooldownSeconds
                )
                : TickTimer.None;
    }

    protected override void OnValidate()
    {
        base.OnValidate();
        startupSeconds = Mathf.Max(0f, startupSeconds);
        maximumActiveSeconds = Mathf.Max(0.02f, maximumActiveSeconds);
        maximumBrakingSeconds = Mathf.Max(0f, maximumBrakingSeconds);
        recoverySeconds = Mathf.Max(0f, recoverySeconds);
        cooldownSeconds = Mathf.Max(0f, cooldownSeconds);
        dashSpeed = Mathf.Max(0.01f, dashSpeed);
        maximumDashDistance = Mathf.Max(0.01f, maximumDashDistance);
        brakingDeceleration = Mathf.Max(0.01f, brakingDeceleration);
        hitRadius = Mathf.Max(0.01f, hitRadius);
        hitCenterHeight = Mathf.Max(0f, hitCenterHeight);
        damage = Mathf.Max(0f, damage);
        cancelWhenTargetBehindSeconds =
            Mathf.Max(0f, cancelWhenTargetBehindSeconds);
    }
}
