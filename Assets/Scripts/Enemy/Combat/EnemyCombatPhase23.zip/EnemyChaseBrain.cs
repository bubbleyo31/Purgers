using Fusion;
using UnityEngine;


/// <summary>
/// Chase State 的共用驅動器。
///
/// Definition 決定 Chase A／B；Prefab 上的 Motor 必須符合。
/// 目的地週期性重算，玩家小幅移動不會每 Tick 讓遠程敵人同步抖動。
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(NetworkObject))]
[RequireComponent(typeof(EnemyActor))]
[RequireComponent(typeof(EnemyPerceptionController))]
[RequireComponent(typeof(EnemyCombatDecisionController))]
public sealed class EnemyChaseBrain :
    NetworkBehaviour
{
    [Header("核心引用")]

    [SerializeField]
    [Tooltip("同 Root 的 EnemyActor。留空自動取得。")]
    private EnemyActor enemyActor;

    [SerializeField]
    [Tooltip("同 Root 的 EnemyPerceptionController。留空自動取得。")]
    private EnemyPerceptionController perception;

    [SerializeField]
    [Tooltip("同 Root 的 EnemyCombatDecisionController。留空自動取得。")]
    private EnemyCombatDecisionController combatDecision;

    [SerializeField]
    [Tooltip("同 Root、符合 Definition Chase Kind 的 Ground／Flying Chase Motor。留空自動取得。")]
    private EnemyChaseMotor chaseMotor;

    [Header("目的地更新")]

    [SerializeField]
    [Min(0.05f)]
    [Tooltip(
        "最短重新規劃間隔，秒。\n" +
        "Chase A 建議 0.15～0.25；Chase B 建議 0.3～0.5，降低同步跟隨感。")]
    private float repathIntervalSeconds =
        0.25f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("玩家相對上次規劃位置移動超過多少公尺才提早重算。0 代表只依固定間隔。")]
    private float targetMovementRepathDistance =
        1f;

    [SerializeField]
    [Min(0.01f)]
    [Tooltip("追逐 Root 距離規劃目的地多少公尺時停止本輪移動，等待下一次規劃。")]
    private float destinationStoppingDistance =
        0.2f;

    [SerializeField]
    [Tooltip("開啟後輸出目的地規劃失敗。大量敵人時建議關閉。")]
    private bool debugChase;

    [Networked]
    public bool HasChaseDestination
    {
        get;
        private set;
    }

    [Networked]
    public Vector3 ChaseDestination
    {
        get;
        private set;
    }

    [Networked]
    public float MoveSpeed
    {
        get;
        private set;
    }

    [Networked]
    public int DestinationSequence
    {
        get;
        private set;
    }

    [Networked]
    private TickTimer RepathTimer
    {
        get;
        set;
    }

    [Networked]
    private Vector3 TargetPositionAtLastPlan
    {
        get;
        set;
    }

    private bool fusionSpawned;
    private bool configurationValid;

    public bool IsFusionSpawned =>
        fusionSpawned &&
        Object != null &&
        Object.IsValid;

    private void Awake()
    {
        ResolveReferences();
    }

    private void OnValidate()
    {
        ResolveReferences();
        repathIntervalSeconds =
            Mathf.Max(0.05f, repathIntervalSeconds);
        targetMovementRepathDistance =
            Mathf.Max(0f, targetMovementRepathDistance);
        destinationStoppingDistance =
            Mathf.Max(0.01f, destinationStoppingDistance);
    }

    public override void Spawned()
    {
        fusionSpawned = true;
        ResolveReferences();

        configurationValid =
            enemyActor != null &&
            enemyActor.Definition != null &&
            chaseMotor != null &&
            chaseMotor.SupportedChaseKind ==
                enemyActor.Definition.ChaseKind &&
            GetComponents<EnemyChaseMotor>().Length == 1;

        if (Object.HasStateAuthority == false)
        {
            return;
        }

        HasChaseDestination = false;
        ChaseDestination = transform.position;
        MoveSpeed = 0f;
        DestinationSequence = 0;
        RepathTimer = TickTimer.None;
        TargetPositionAtLastPlan = transform.position;

        if (configurationValid == false)
        {
            Debug.LogError(
                "[Enemy Chase] 必須且只能掛一個符合 Definition Chase Kind 的 Motor，追逐暫停。",
                this
            );
        }
    }

    public override void Despawned(
        NetworkRunner runner,
        bool hasState
    )
    {
        chaseMotor?.Stop();
        fusionSpawned = false;
    }

    public override void FixedUpdateNetwork()
    {
        if (Object.HasStateAuthority == false ||
            configurationValid == false ||
            enemyActor == null ||
            perception == null ||
            combatDecision == null)
        {
            return;
        }

        MoveSpeed = 0f;

        EnemyStateController state =
            enemyActor.StateController;

        if (enemyActor.IsAlive == false ||
            state == null ||
            state.CanRunBrain == false ||
            perception.HasTarget == false ||
            (state.CurrentBrainState != EnemyBrainState.Chase &&
             state.CurrentBrainState != EnemyBrainState.Combat))
        {
            StopChasing();
            return;
        }

        Vector3 targetPosition =
            perception.HasDirectSight
                ? perception.GetPlayerObservationPosition(
                    perception.CurrentTarget
                )
                : perception.LastKnownTargetPosition;

        bool targetMovedEnough =
            targetMovementRepathDistance > 0f &&
            Vector3.SqrMagnitude(
                targetPosition -
                TargetPositionAtLastPlan
            ) >=
            targetMovementRepathDistance *
            targetMovementRepathDistance;

        if (HasChaseDestination == false ||
            RepathTimer.ExpiredOrNotRunning(Runner) ||
            targetMovedEnough)
        {
            TryRepath(targetPosition);
        }

        if (HasChaseDestination == false)
        {
            return;
        }

        if (chaseMotor.TickMove(
                ChaseDestination,
                Runner.DeltaTime,
                destinationStoppingDistance,
                out float actualSpeed
            ) == false)
        {
            HasChaseDestination = false;
            RepathTimer =
                TickTimer.CreateFromSeconds(
                    Runner,
                    repathIntervalSeconds
                );
            chaseMotor.Stop();
            return;
        }

        MoveSpeed = actualSpeed;

        if (Vector3.Distance(
                transform.position,
                ChaseDestination
            ) <= destinationStoppingDistance)
        {
            HasChaseDestination = false;
            chaseMotor.Stop();
        }
    }

    private void TryRepath(
        Vector3 targetPosition
    )
    {
        TargetPositionAtLastPlan =
            targetPosition;

        RepathTimer =
            TickTimer.CreateFromSeconds(
                Runner,
                repathIntervalSeconds
            );

        if (chaseMotor.TryPlanDestination(
                perception.CurrentTarget,
                targetPosition,
                perception.HasDirectSight,
                combatDecision.PreferredMinimumAttackDistance,
                combatDecision.PreferredMaximumAttackDistance,
                out Vector3 destination
            ))
        {
            ChaseDestination = destination;
            HasChaseDestination = true;
            DestinationSequence++;
            return;
        }

        HasChaseDestination = false;
        chaseMotor.Stop();

        if (debugChase)
        {
            Debug.Log(
                "[Enemy Chase] 目前找不到安全完整路徑，等待下次重算。",
                this
            );
        }
    }

    private void StopChasing()
    {
        if (HasChaseDestination)
        {
            HasChaseDestination = false;
            RepathTimer = TickTimer.None;
            chaseMotor?.Stop();
        }
    }

    private void ResolveReferences()
    {
        if (enemyActor == null)
        {
            enemyActor = GetComponent<EnemyActor>();
        }

        if (perception == null)
        {
            perception =
                GetComponent<EnemyPerceptionController>();
        }

        if (combatDecision == null)
        {
            combatDecision =
                GetComponent<EnemyCombatDecisionController>();
        }

        if (chaseMotor == null)
        {
            chaseMotor =
                GetComponent<EnemyChaseMotor>();
        }
    }
}
