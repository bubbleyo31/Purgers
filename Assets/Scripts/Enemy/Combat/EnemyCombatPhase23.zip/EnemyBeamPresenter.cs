using UnityEngine;
using UnityEngine.Events;


/// <summary>
/// 遠程 B 的本地 LineRenderer 與射擊事件。
/// 只讀取 Networked 狀態，不做 Raycast 或傷害。
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(LineRenderer))]
public sealed class EnemyBeamPresenter :
    MonoBehaviour
{
    [Header("引用")]

    [SerializeField]
    [Tooltip("Enemy Root 的 EnemyRangedBeamAttack。留空會往父階層尋找。")]
    private EnemyRangedBeamAttack beamAttack;

    [SerializeField]
    [Tooltip("Enemy Root 的 EnemyCombatDecisionController。留空會往父階層尋找。")]
    private EnemyCombatDecisionController combatDecision;

    [SerializeField]
    [Tooltip("顯示瞄準與發射 Beam 的 LineRenderer。Use World Space 必須開啟。")]
    private LineRenderer lineRenderer;

    [Header("本機發射呈現")]

    [SerializeField]
    [Tooltip("每次觀察到新的 BeamShotSequence 時觸發一次。可接世界槍聲、Muzzle Flash 或 Camera 可見的 VFX，不可接傷害。")]
    private UnityEvent onBeamFired =
        new UnityEvent();

    private int observedShotSequence;
    private bool initialized;

    private void Awake()
    {
        ResolveReferences();

        if (lineRenderer != null)
        {
            lineRenderer.positionCount = 2;
            lineRenderer.enabled = false;
        }
    }

    private void OnEnable()
    {
        initialized = false;
    }

    private void OnDisable()
    {
        if (lineRenderer != null)
        {
            lineRenderer.enabled = false;
        }
    }

    private void LateUpdate()
    {
        if (beamAttack == null ||
            combatDecision == null ||
            combatDecision.IsFusionSpawned == false ||
            lineRenderer == null)
        {
            return;
        }

        bool isTelegraph =
            combatDecision.ActiveOptionId ==
                EnemyCombatOptionId.RangedAttackB &&
            (combatDecision.CurrentActionPhase ==
                 EnemyCombatActionPhase.Tracking ||
             combatDecision.CurrentActionPhase ==
                 EnemyCombatActionPhase.LockedDelay);

        bool showLine =
            isTelegraph ||
            beamAttack.IsShotVisualActive;

        lineRenderer.enabled = showLine;

        if (showLine)
        {
            lineRenderer.SetPosition(
                0,
                beamAttack.BeamStartPoint
            );
            lineRenderer.SetPosition(
                1,
                beamAttack.BeamEndPoint
            );
        }

        int sequence =
            beamAttack.BeamShotSequence;

        if (initialized == false)
        {
            observedShotSequence = sequence;
            initialized = true;
            return;
        }

        if (sequence != observedShotSequence)
        {
            observedShotSequence = sequence;
            onBeamFired?.Invoke();
        }
    }

    private void ResolveReferences()
    {
        if (beamAttack == null)
        {
            beamAttack =
                GetComponentInParent<EnemyRangedBeamAttack>();
        }

        if (combatDecision == null)
        {
            combatDecision =
                GetComponentInParent<EnemyCombatDecisionController>();
        }

        if (lineRenderer == null)
        {
            lineRenderer =
                GetComponent<LineRenderer>();
        }
    }

    private void OnValidate()
    {
        ResolveReferences();
    }
}
