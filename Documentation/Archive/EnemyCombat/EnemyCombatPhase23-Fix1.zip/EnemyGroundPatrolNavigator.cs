using UnityEngine;
using UnityEngine.AI;

/// <summary>
/// 地面巡邏：使用烘焙 NavMesh 計算完整路徑，由 Fusion Tick 推進路徑拐點。
/// 不需要 NavMeshAgent，也不允許另一個 Agent 自行更新同一個 Root。
/// 本階段不跨 OffMeshLink、不處理群體避讓；適合先驗證普通連通地面的巡邏。
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(EnemyMovementOwnership))]
public sealed class EnemyGroundPatrolNavigator : EnemyPatrolNavigator
{
    [Header("地面 NavMesh")]
    [SerializeField, Tooltip("NavMesh 的 Agent Type ID，預設 Humanoid 為 0。必須與烘焙的 Agent Type 一致。")]
    private int agentTypeId = 0;
    [SerializeField, Min(0.01f), Tooltip("從 Root 腳底／巡邏節點搜尋最近 NavMesh 的最大距離。建議 0.3，避免投影到另一層樓。")]
    private float navMeshSnapDistance = 0.3f;
    [SerializeField, Min(0.01f), Tooltip("允許每一步與 NavMesh 高度修正的最大距離。這不是跳躍高度；過大會跨樓層。")]
    private float maximumStepProjection = 0.25f;
    [SerializeField, Min(0f), Tooltip("離地後自行向下加速的重力，公尺／秒平方。Support／Tank 控制期間暫停本模組。")]
    private float gravity = 25f;
    [SerializeField, Min(0.01f), Tooltip("向下速度上限，公尺／秒。")]
    private float terminalFallSpeed = 30f;
    [SerializeField, Min(0.001f), Tooltip("離地小於這個距離時視為已落地，公尺。")]
    private float groundedProbeDistance = 0.08f;

    private NavMeshPath path;
    private Vector3[] corners;
    private int cornerIndex;
    private float fallSpeed;
    private bool grounded;
    private Vector3 destination;
    public override EnemyLocomotionKind SupportedLocomotion => EnemyLocomotionKind.Ground;
    private NavMeshQueryFilter Filter => new NavMeshQueryFilter
        { agentTypeID = agentTypeId, areaMask = NavMesh.AllAreas };

    protected override void Awake()
    {
        base.Awake();
        path = new NavMeshPath();
    }

    public override bool TryBegin(Vector3 target, out Vector3 actualDestination)
    {
        actualDestination = target;
        Stop();
        if (!ConfigurationValid()) return false;

        // 不依賴 FixedUpdateNetwork 的元件執行順序。
        // 即使本 Tick 先做待機決策，也先在這裡刷新一次腳底狀態。
        RefreshGroundedState();
        if (!grounded) return false;

        if (!NavMesh.SamplePosition(transform.position, out NavMeshHit start, navMeshSnapDistance, Filter) ||
            !NavMesh.SamplePosition(target, out NavMeshHit end, navMeshSnapDistance, Filter)) return false;
        if (!NavMesh.CalculatePath(start.position, end.position, Filter, path) ||
            path.status != NavMeshPathStatus.PathComplete) return false;
        corners = path.corners;
        if (corners.Length == 0) return false;
        destination = end.position;
        actualDestination = destination;
        cornerIndex = corners.Length > 1 ? 1 : 0;
        return true;
    }

    public override EnemyPatrolMoveResult TickMove(float deltaTime, float arrivalDistance)
    {
        if (corners == null || !ConfigurationValid()) return EnemyPatrolMoveResult.Failed;
        if (!Ownership.CanMove || !grounded) return EnemyPatrolMoveResult.Moving;
        if (Vector3.Distance(transform.position, destination) <= arrivalDistance)
            return EnemyPatrolMoveResult.Arrived;
        while (cornerIndex < corners.Length - 1 &&
            Vector3.Distance(transform.position, corners[cornerIndex]) < 0.06f) cornerIndex++;
        Vector3 proposed = Vector3.MoveTowards(transform.position, corners[cornerIndex], patrolSpeed * deltaTime);
        if (!NavMesh.SamplePosition(transform.position, out NavMeshHit currentSurface,
                navMeshSnapDistance, Filter) ||
            !NavMesh.SamplePosition(proposed, out NavMeshHit surface, maximumStepProjection, Filter) ||
            // 不允許一步跨出 NavMesh 邊界，包含缺口與未實作的跳躍 Link。
            NavMesh.Raycast(currentSurface.position, surface.position, out _, Filter))
            return EnemyPatrolMoveResult.Failed;
        if (!TryMove(surface.position, deltaTime)) return EnemyPatrolMoveResult.Failed;
        return Vector3.Distance(transform.position, destination) <= arrivalDistance ?
            EnemyPatrolMoveResult.Arrived : EnemyPatrolMoveResult.Moving;
    }

    public override void TickSupport(float deltaTime)
    {
        if (!ConfigurationValid() || Ownership.IsExternallyMoved) { fallSpeed = 0f; return; }
        // 腳底 Root 正上方往下探測，保留少許容差。不在空中直接 Warp 回 NavMesh。
        RefreshGroundedState();
        if (grounded)
        {
            fallSpeed = 0f;
            return;
        }

        Vector3 origin = transform.position + Vector3.up * 0.1f;
        fallSpeed = Mathf.Min(terminalFallSpeed, fallSpeed + gravity * deltaTime);
        float step = fallSpeed * deltaTime;
        if (Runner.GetPhysicsScene().Raycast(origin, Vector3.down, out RaycastHit support,
                0.1f + step, obstacleMask, QueryTriggerInteraction.Ignore))
        {
            Vector3 landing = transform.position;
            landing.y = support.point.y;
            // 腳底落地射線決定高度，身體膠囊仍需確認沒有撞進牆體。
            if (IsSegmentClear(transform.position, landing + Vector3.up * collisionSkin))
                transform.position = landing + Vector3.up * collisionSkin;
            fallSpeed = 0f;
        }
        else TryMove(transform.position + Vector3.down * step, deltaTime);
    }

    public override void Stop() { corners = null; cornerIndex = 0; }

    private void RefreshGroundedState()
    {
        Vector3 origin = transform.position + Vector3.up * 0.1f;
        grounded = Runner.GetPhysicsScene().Raycast(
            origin,
            Vector3.down,
            out _,
            0.1f + groundedProbeDistance,
            obstacleMask,
            QueryTriggerInteraction.Ignore);
    }
}
