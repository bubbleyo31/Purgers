using Fusion;
using UnityEngine;


/// <summary>
/// 近戰 A：靠近玩家後原地揮擊。
///
/// Startup 期間只面向玩家，不做突進；進入 Active 的第一個 Tick
/// 使用一次 SphereCast 決定是否命中，接著等待 Active Window 與 Recovery。
/// 傷害完全由 State Authority 的 TickTimer 觸發，不使用 Animation Event。
/// </summary>
[DisallowMultipleComponent]
public sealed class EnemyMeleeSwingAttack :
    EnemyCombatOption
{
    [Header("近戰 A 引用")]

    [SerializeField]
    [Tooltip("揮擊判定起點。建議使用胸口前方的穩定空物件；若留空，使用 Enemy Root 加上 Hit Center Height。")]
    private Transform attackOrigin;

    [Header("近戰 A 時間")]

    [SerializeField]
    [Min(0f)]
    [Tooltip("從開始揮擊到傷害判定真正發生的秒數。請依動畫接觸幀換算；傷害不使用 Animation Event。")]
    private float activeDelaySeconds =
        0.3f;

    [SerializeField]
    [Min(0.02f)]
    [Tooltip("傷害判定後，Animator 保持在 Active 階段的秒數。本版只在進入 Active 時判定一次，不會每 Tick 重複扣血。")]
    private float activeWindowSeconds =
        0.1f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("Active 結束後的收招秒數。期間不可移動、再次攻擊或防禦。")]
    private float recoverySeconds =
        0.45f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("完整揮擊結束或被取消後才開始計算的冷卻秒數。")]
    private float cooldownSeconds =
        1.2f;

    [SerializeField]
    [Min(1f)]
    [Tooltip("Startup 期間面向玩家的最大水平轉向速度，度／秒。進入 Active 後鎖定方向。")]
    private float startupTurnSpeed =
        420f;

    [SerializeField]
    [Range(1f, 180f)]
    [Tooltip("允許開始揮擊時，玩家與敵人正前方的最大水平夾角。80 代表正面 160 度。")]
    private float startFacingHalfAngle =
        80f;

    [Header("近戰 A 判定")]

    [SerializeField]
    [Tooltip("揮擊會命中的 Layer。必須包含 Player 與場景實體，不可包含 Enemy Layer；牆比玩家更近時會擋住攻擊。")]
    private LayerMask swingHitMask;

    [SerializeField]
    [Min(0.01f)]
    [Tooltip("揮擊球形掃掠半徑，公尺。數值越大，左右涵蓋角度越寬。")]
    private float hitRadius =
        0.55f;

    [SerializeField]
    [Min(0.01f)]
    [Tooltip("從判定起點沿鎖定方向向前掃掠的距離，公尺。")]
    private float attackReach =
        1.6f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("判定起點留空時，從 Enemy Root 向上偏移的高度，公尺。")]
    private float hitCenterHeight =
        0.9f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("把 SphereCast 起點往敵人後方退多少公尺，避免玩家貼得太近、已與起始球重疊而漏判。Hit Mask 不可包含 Enemy。")]
    private float closeRangeBackstep =
        0.35f;

    [SerializeField]
    [Min(0f)]
    [Tooltip("命中玩家時造成的基礎近戰傷害。一次揮擊最多命中第一個玩家一次。")]
    private float damage =
        18f;

    [Header("除錯")]

    [SerializeField]
    [Tooltip("開啟後輸出每次揮擊是命中玩家、被場景擋住或揮空。大量敵人時建議關閉。")]
    private bool debugMeleeSwing;

    [Networked]
    public TickTimer PhaseTimer
    {
        get;
        private set;
    }

    [Networked]
    public TickTimer CooldownTimer
    {
        get;
        private set;
    }

    [Networked]
    public Vector3 LockedSwingDirection
    {
        get;
        private set;
    }

    [Networked]
    public int DamageSequence
    {
        get;
        private set;
    }

    [Networked]
    public bool LastSwingHitPlayer
    {
        get;
        private set;
    }

    public override EnemyActionState ActionState =>
        EnemyActionState.Attack;

    public override EnemyActionLockFlags LocksWhileActive =>
        EnemyActionLockFlags.Movement |
        EnemyActionLockFlags.Rotation |
        EnemyActionLockFlags.Navigation |
        EnemyActionLockFlags.Attack |
        EnemyActionLockFlags.Defense;

    public override void Spawned()
    {
        if (Object.HasStateAuthority == false)
        {
            return;
        }

        PhaseTimer = TickTimer.None;
        CooldownTimer = TickTimer.None;
        LockedSwingDirection = transform.forward;
        DamageSequence = 0;
        LastSwingHitPlayer = false;
    }

    public override bool IsCooldownReady(
        NetworkRunner runner
    )
    {
        return CooldownTimer.ExpiredOrNotRunning(runner);
    }

    public override bool CanStartOption(
        in EnemyCombatContext context
    )
    {
        if (swingHitMask.value == 0)
        {
            return false;
        }

        Vector3 toTarget =
            Vector3.ProjectOnPlane(
                context.TargetPosition - transform.position,
                Vector3.up
            );

        return
            toTarget.sqrMagnitude > 0.0001f &&
            Vector3.Angle(
                transform.forward,
                toTarget
            ) <= startFacingHalfAngle;
    }

    public override void BeginOption(
        in EnemyCombatContext context
    )
    {
        LastSwingHitPlayer = false;
        FaceTarget(context);

        PhaseTimer =
            activeDelaySeconds > 0f
                ? TickTimer.CreateFromSeconds(
                    Runner,
                    activeDelaySeconds
                )
                : TickTimer.None;
    }

    public override EnemyCombatOptionTickResult TickOption(
        in EnemyCombatContext context
    )
    {
        switch (context.Controller.CurrentActionPhase)
        {
            case EnemyCombatActionPhase.Startup:
                FaceTarget(context);

                if (PhaseTimer.ExpiredOrNotRunning(Runner))
                {
                    BeginActive(context);
                }

                return EnemyCombatOptionTickResult.Running;

            case EnemyCombatActionPhase.Active:
                if (PhaseTimer.ExpiredOrNotRunning(Runner))
                {
                    BeginRecovery(context);
                }

                return EnemyCombatOptionTickResult.Running;

            case EnemyCombatActionPhase.Recovery:
                if (PhaseTimer.ExpiredOrNotRunning(Runner))
                {
                    StartCooldown();
                    return EnemyCombatOptionTickResult.Completed;
                }

                return EnemyCombatOptionTickResult.Running;

            default:
                StartCooldown();
                return EnemyCombatOptionTickResult.Cancelled;
        }
    }

    public override void CancelOption(
        in EnemyCombatContext context
    )
    {
        PhaseTimer = TickTimer.None;
        StartCooldown();
    }

    private void BeginActive(
        in EnemyCombatContext context
    )
    {
        Vector3 direction =
            Vector3.ProjectOnPlane(
                context.TargetPosition - transform.position,
                Vector3.up
            );

        LockedSwingDirection =
            direction.sqrMagnitude > 0.0001f
                ? direction.normalized
                : transform.forward;

        transform.rotation =
            Quaternion.LookRotation(LockedSwingDirection);

        ApplySwingDamage(context);

        PhaseTimer = TickTimer.CreateFromSeconds(
            Runner,
            activeWindowSeconds
        );

        context.Controller.TrySetActionPhase(
            this,
            EnemyCombatActionPhase.Active
        );
    }

    private void ApplySwingDamage(
        in EnemyCombatContext context
    )
    {
        Vector3 center =
            attackOrigin != null
                ? attackOrigin.position
                : transform.position +
                  Vector3.up * hitCenterHeight;

        Vector3 castStart =
            center -
            LockedSwingDirection * closeRangeBackstep;

        float castDistance =
            attackReach + closeRangeBackstep;

        LastSwingHitPlayer = false;
        DamageSequence++;

        if (Runner.GetPhysicsScene().SphereCast(
                castStart,
                hitRadius,
                LockedSwingDirection,
                out RaycastHit hit,
                castDistance,
                swingHitMask,
                QueryTriggerInteraction.Ignore
            ))
        {
            PlayerHealth health =
                hit.collider != null
                    ? hit.collider.GetComponentInParent<PlayerHealth>()
                    : null;

            if (health != null &&
                health.Object != null &&
                health.IsAlive)
            {
                LastSwingHitPlayer =
                    EnemyDamageUtility.TryDamagePlayer(
                        context.Actor,
                        health.Object,
                        hit.collider.gameObject,
                        hit.point,
                        hit.normal,
                        LockedSwingDirection,
                        damage,
                        DamageType.Melee,
                        DamageSequence,
                        out DamageResult result
                    ) && result.HasEffectiveDamage;
            }

            if (debugMeleeSwing)
            {
                Debug.Log(
                    LastSwingHitPlayer
                        ? "[Enemy Melee A] 揮擊命中玩家。"
                        : "[Enemy Melee A] 揮擊先碰到場景或無效目標。",
                    this
                );
            }

            return;
        }

        if (debugMeleeSwing)
        {
            Debug.Log(
                "[Enemy Melee A] 本次揮擊沒有命中。",
                this
            );
        }
    }

    private void BeginRecovery(
        in EnemyCombatContext context
    )
    {
        PhaseTimer =
            recoverySeconds > 0f
                ? TickTimer.CreateFromSeconds(
                    Runner,
                    recoverySeconds
                )
                : TickTimer.None;

        context.Controller.TrySetActionPhase(
            this,
            EnemyCombatActionPhase.Recovery
        );
    }

    private void FaceTarget(
        in EnemyCombatContext context
    )
    {
        Vector3 direction =
            Vector3.ProjectOnPlane(
                context.TargetPosition - transform.position,
                Vector3.up
            );

        if (direction.sqrMagnitude <= 0.0001f)
        {
            return;
        }

        transform.rotation =
            Quaternion.RotateTowards(
                transform.rotation,
                Quaternion.LookRotation(direction),
                startupTurnSpeed * context.DeltaTime
            );
    }

    private void StartCooldown()
    {
        CooldownTimer =
            cooldownSeconds > 0f
                ? TickTimer.CreateFromSeconds(
                    Runner,
                    cooldownSeconds
                )
                : TickTimer.None;
    }

    protected override void OnValidate()
    {
        base.OnValidate();
        activeDelaySeconds = Mathf.Max(0f, activeDelaySeconds);
        activeWindowSeconds = Mathf.Max(0.02f, activeWindowSeconds);
        recoverySeconds = Mathf.Max(0f, recoverySeconds);
        cooldownSeconds = Mathf.Max(0f, cooldownSeconds);
        startupTurnSpeed = Mathf.Max(1f, startupTurnSpeed);
        hitRadius = Mathf.Max(0.01f, hitRadius);
        attackReach = Mathf.Max(0.01f, attackReach);
        hitCenterHeight = Mathf.Max(0f, hitCenterHeight);
        closeRangeBackstep = Mathf.Max(0f, closeRangeBackstep);
        damage = Mathf.Max(0f, damage);
    }
}
